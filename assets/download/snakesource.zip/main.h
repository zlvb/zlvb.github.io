
#include "snake.h"
#include "CXWIN.h"
#include <math.h>
using namespace std;

#define WILLHIT (mysnake->head_x()==548 && dir==S_RIGHT) || (mysnake->head_x()==80 && dir==S_LEFT) || (mysnake->head_y()==0 && dir==S_UP) || (mysnake->head_y()==468 && dir==S_DOWN) || mysnake->isTouch()

#define S_SPEED 125

CXWIN frm;

int level=0;

CXDDR* bg;

CXDDR* lp;
CXDDR* rp;

CXTXT sco;

int sc=0;

int speed;

CXDSD* bgs;

int sp2;

CXDIP Input;

int dir=S_RIGHT;


snake* mysnake;


void restart();

snake_block s1;

bool isdie=false;


void move();

