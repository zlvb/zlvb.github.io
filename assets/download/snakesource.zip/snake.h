#include "CXDDR.h"
#include "CXDIP.h"
#include "CXTXT.h"
#include "CXDSD.h"



#define S_LEFT 0x11
#define S_RIGHT 0x12
#define S_DOWN 0x13
#define S_UP 0x14

#define S_SLENGTH 5

struct snake_block
{
	CXDDR skin;				//�ߵ�ͼƬ
	snake_block* pre_block;//�ߵ�ǰһ���ָ��
};



class snake
{
public:

	snake();
	int	head_x();
	int head_y();
	int snake_length();
	void go_up();
	void go_down();
	void go_left();
	void go_right();

	void loadSkin(char* filename);

	void go(int sdir);

	void eat_block();

	void send2back();

	int direction();

	bool isHitSelf();
	
	void PutEgg();

	snake_block* Egg();

	bool isTouch();


	

private:

	int SnakeLength;
	int sdir;
	snake_block* snake_end;//ָ����β
	snake_block* snake_front;//ָ����ͷ
	unsigned long isInied;

	snake_block* egg;
	
};