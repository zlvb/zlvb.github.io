#include "main.h"




CXMain()
{


	frm.SetClientBKColor(BLACK_PEN);

	frm.ShowMouseCursor(FALSE);

	HWND hWnd=frm.CreateWin(hInstance,WinProc,"Snake",WS_NORMALWINDOW & ~WS_MAXIMIZEBOX);




	Input.InitCXDIP(hWnd,1,0,1);

	bgs=new CXDSD(STATICSOUND,hWnd);



	bgs->LoadWav(".\\eat.wav");

		
		
		mysnake=new snake();
	


	lp=new CXDDR;
	rp=new CXDDR;

	bg=new CXDDR();

	CXDDR::InitDDraw(hWnd,TRUE,640,480,16,NULL,NULL);

	
	
	speed=S_SPEED;

	lp->LoadBMP(".\\leftp.bmp");
	rp->LoadBMP(".\\rightp.bmp");

	rp->x=560;

	bg->LoadBMP(".\\bg.bmp");

	mysnake->loadSkin(".\\block2.bmp");


	

	mysnake->Egg()->skin.LoadBMP(".\\block2.bmp");

	mysnake->PutEgg();
	
	sp2=speed;

	CALL_DEFAULT_MESSAGEWHILE(frm,move());

}


USING_DEFAULT_WINPROC(frm);


void move()
{
	Input.GetDInputData();

	int dir0=Input.InputInfo.Now.KeyBoard.Key;


	if(dir0==DIK_DOWN)
	{
		if(mysnake->direction()!=S_UP)
		dir=S_DOWN;
	}


		


	else if(dir0==DIK_UP)
	{
		if(mysnake->direction()!=S_DOWN)
		dir=S_UP;
	}

		



	else if(dir0==DIK_LEFT)
	{
		if(mysnake->direction()!=S_RIGHT)
		dir=S_LEFT;
	}

		



	else if(dir0==DIK_RIGHT)
	{
		if(mysnake->direction()!=S_LEFT)
		dir=S_RIGHT;
	}

	else if(dir0==DIK_RBRACKET )
	{
		if(mysnake->direction()==S_RIGHT || mysnake->direction()==S_LEFT)
			dir=S_UP;
		else if(mysnake->direction()==S_UP || mysnake->direction()==S_DOWN)
			dir=S_RIGHT;

	}

	else if(dir0==DIK_Z)
	{
		if(mysnake->direction()==S_RIGHT || mysnake->direction()==S_LEFT)
			dir=S_DOWN;
		else if(mysnake->direction()==S_UP || mysnake->direction()==S_DOWN)
			dir=S_LEFT;

	}

		

	else if(dir0==DIK_ESCAPE)
	{
		delete mysnake;
		
		delete bgs;
		frm.UNLOAD(0);
		exit(0);
		
	}

	else if(dir0==DIK_RETURN)
	{
		
			ShellExecute(NULL,"open",".\\snake.exe",NULL,NULL, SW_SHOWNORMAL );
			frm.UNLOAD(0);
	}






Delay(sp2){
			

		if(mysnake->head_x()<=548 && mysnake->head_x()>=80 && mysnake->head_y()>=0 && mysnake->head_y()<=480 && !mysnake->isHitSelf())
		{
			if(mysnake->head_x()==mysnake->Egg()->skin.x && mysnake->head_y()==mysnake->Egg()->skin.y)
			{
				bgs->Play(0,1);
				mysnake->eat_block();
				mysnake->PutEgg();
				sc+=9;
				
				speed=S_SPEED-(sc/135)*10;
				level=sc/135;
				if(level>9)level=9;
				if(speed<15)speed=15;
				
			}

			
					mysnake->go(dir);

				if(WILLHIT)
					sp2=250;
				else
					sp2=speed;
		}

		

}EndDelay;

/*
	Delay(500){

		if(!(mysnake->head_x()<=548 && mysnake->head_x()>=80 && mysnake->head_y()>=0 && mysnake->head_y()<=480 && !mysnake->isHitSelf()))
		{
			return;
		}

	}EndDelay;


Delay(speed){

			if(mysnake->head_x()==mysnake->Egg()->skin.x && mysnake->head_y()==mysnake->Egg()->skin.y)
			{
				bgs->Play(0,1);
				mysnake->eat_block();
				mysnake->PutEgg();
				sc+=9;
				
				speed=50-(sc/135)*20;
				if(speed<0)speed=0;
			}
			mysnake->go(dir);

}EndDelay;

*/
	

	

	bg->SendToBack();


	mysnake->Egg()->skin.SendToBack();

	mysnake->send2back();

	lp->SendToBack();
	rp->SendToBack();

	sco.TextBackSurf(580,80,"Score",RGB(0,0,0),0);
	sco.TextBackSurf(580,100,LONG(sc),RGB(0,0,0),0);
	sco.TextBackSurf(580,140,"Level",RGB(0,0,0),0);
	sco.TextBackSurf(580,160,LONG(level),RGB(0,0,0),0);
	sco.ReMain();

	CXDDR::Flip(&frm.Get_rectWin());

	
}


